from stylize import *

style = "../img/style1.jpg"
content = "../img/content2.jpg"
stylize(style, content, 512);